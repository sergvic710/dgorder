<?php
/*
Plugin Name: designecoprint order
Description: Crop picture and order
Version: 0.1
Author: Iakovlev Sergei
Author URI:
License: GPL2
*/

define('BW', '0.1');
require_once dirname(__FILE__) . '/dgOrder_Install.php';
require_once dirname(__FILE__) . '/dgOrder_Setting.php';

if (is_admin())
    $my_settings_page = new dgOrder_Setting();

register_activation_hook(__FILE__, array('dgOrder_Install', 'activate'));
register_deactivation_hook(__FILE__, array('dgOrder_Install', 'deactivate'));


add_action('wp_enqueue_scripts', 'dg_scripts');
function dg_scripts()
{
    $localVars = array(
        'ajaxurl' => admin_url('admin-ajax.php'),
    );
    wp_enqueue_script('jquery-jcrop', '/wp-content/plugins/dgorder/js/jquery.Jcrop.min.js', array());
    wp_enqueue_script('dg-order', '/wp-content/plugins/dgorder/js/dg-order~~.js', array());
    wp_localize_script('dg-order', 'dgorder', $localVars);
}

add_action('wp_enqueue_scripts', 'dg_styles');
function dg_styles()
{
    wp_register_style('dg-jcrop-styles', plugins_url('/css/jquery.Jcrop.css', __FILE__));
    wp_enqueue_style('dg-jcrop-styles');
    wp_register_style('dg-styles', plugins_url('/css/dgorder.css', __FILE__));
    wp_enqueue_style('dg-styles');
}

add_action('wp_ajax_dgcropimg', 'dgCropImage');
add_action('wp_ajax_nopriv_dgcropimg', 'dgCropImage');


add_shortcode('dgorder', 'dgOrder');
function dgOrder()
{
    if( isset($_POST['dg-submit-order'])) {
        $subject = 'Поступил заказ';
        $message = "Имя картинки : Тест\n";
        $message .= "Площадь : ".$_POST['square']." кв.м.\n";
        $message .= "Цена : ".$_POST['price']."руб.\n";
        $message .= "Имя : ".$_POST['Name']."\n";
        $message .= "Телефон : ".$_POST['Phone']."\n";
        $message .= "Email : ".$_POST['Email']."\n";
        $message .= "Комментарий к заказу : \n".$_POST['Note']."\n";
        $headers = "From: web@localhost\r\nReply-To: web@localhost";

        $info = pathinfo($_POST['crop-img-src']);
        $file = plugin_dir_path(__FILE__) . 'crops/'.$info['basename'];

        $dgOrder_settings = get_option( 'dgOrder_settings' );
        $dgOrder_settings = maybe_unserialize( $dgOrder_settings );

        wp_mail($dgOrder_settings['admin_email'],$subject,$message,$headers,$file);
        wp_redirect('/order/');
        exit();
    }


    if (isset($_GET['id']) && $_GET['id'] != 0) {
        $img = wp_get_attachment_image_src($_GET['id'], 'full');
        $aspect_ratio = $img[1]/$img[2];
        $dgOrder_settings = get_option( 'dgOrder_settings' );
        $dgOrder_settings = maybe_unserialize( $dgOrder_settings );
    } else {
        $html = '<div class="dg-content"><h1>Картинка не найдена</h1></div>';
        return $html;
    } ?>

    <div id="dg-content">

        <ul class="dg-steps">
            <li>
                <div class="dg-sel-steps" id="dg-sel-step1">Выберите размер</div>
            </li>
            <li>
                <div class="dg-sel-steps" id="dg-sel-step2">Выберите подложку</div>
            </li>
            <li>Заказ</li>
        </ul>
        <div class="dg-sel-fac" id="dg-sel-fac1">Фактура 1</div>
        <div class="dg-sel-fac" id="dg-sel-fac2">Фактура 2</div>
        <div class="dg-sel-fac" id="dg-sel-fac3">Фактура 3</div>

        <div id="dg-step1-cont">
            <div class="dg-main-crop">

                <div class="dg-clr">
                    <div class="dg-crop-b-header"><b>Выбор размера</b></div>
                    <div class="dg-crop-b-cont clr">
                        <div class="dg-b-input" style="float:left; margin-right: 40px;"><b>Ширина: </b>
                            <input type="text" value="" id="widthOn" style=" width: 34px; "> см
                        </div>
                        <div class="dg-b-input" style="float:left;"><b>Высота: </b>
                            <input type="text" value="200" id="heightOn" style=" width: 34px; "> см
                        </div>
                        <input type="hidden" value="<?= sprintf('%F', $aspect_ratio) ?>" id="aspectRatio">
                        <input type="hidden" value="<?= $_GET['id'] ?>" id="idimage">

                        <div class="dg-btn-reset" onclick="window.location.reload()">Сбросить</div>
                        <div class="dg-aspect-Ratio-box">
                            <input type="checkbox" id="SOR"><label for="SOR">Сохранять пропорции</label>
                        </div>
                    </div>
                    <div class="dg-mainpage_info__shadow" style=" margin: 0 auto; background-size: 100%; "></div>
                </div>

                <div class="m-t-15">
                    <div class="dg-move-polz">Выберитеберите нужный фрагмент изображения.</div>
                    <div class="dg-crop-b-cont">
                        <div class="dg-crop-step1">
                            <img id="for-crop" alt="" src="<?=$img[0]?>">
                        </div>
                    </div>
                </div>

                <input type="hidden" id="x1" name="x1" value="0">
                <input type="hidden" id="y1" name="y1" value="0">
                <input type="hidden" id="x2" name="x2" value="<?= $img[1] ?>">
                <input type="hidden" id="y2" name="y2" value="<?= $img[2] ?>">
                <input type="hidden" id="w" name="w" value="<?= $img[1] ?>">
                <input type="hidden" id="h" name="h" value="<?= $img[2] ?>">

            </div>
            <input type="hidden" class="" id="cartwall" value="none">
            <input type="button" class="" id="get-crop" value="Далее">
        </div>

        <div id="dg-step2-cont">
            <div id="dg-crop-cont">
                <!--                <div id="dg-crop-facture" style="background: url('/wp-content/uploads/2016/02/treshinizoloto.png');">-->
                <div id="dg-crop-facture">
                </div>
                <div id="dg-crop-img">
                    <img src="">
                </div>

            </div>
            <div id="dg-info">
                <div class="dg-info-col1">
                    <div>
                        <span class="dg-width-name">Ширина:</span>
                        <span class="dg-width-value"></span> см.
                    </div>
                    <div>
                        <span class="dg-height-name">Высота:</span>
                        <span class="dg-height-value"></span> см.
                    </div>
                    <div>
                        <span class="dg-square-name">Площать:</span>
                        <span class="dg-square-value"></span> м. <sup>2</sup>
                    </div>
                </div>
                <div class="dg-info-col2">
                    <div>
                        <span class="dg-priceone-name">Цена за 1 м. <sup>2</sup></span>
                        <span class="dg-priceone-value"><?=$dgOrder_settings['pricem2']?></span> руб.
                    </div>
                    <div>
                        <span class="dg-summe-name">Итого:</span>
                        <span class="dg-summe-value"></span> руб.
                    </div>
                    <div>
                        <span class="dg-square-name">Площать:</span>
                        <span class="dg-square-value"></span> м. <sup>2</sup>
                    </div>
                </div>
            </div>
            <input type="button" id="get-order" value="Оформить заказ">
        </div>

        <div id="dg-order">
            <h1>Оформление заказа</h1>
            <form method="post" >
                <input type="hidden" id="SQUARE" name="square" value="">
                <input type="hidden" id="PRICE" name="price" value="">
                <input type="hidden" id="PRICEM2" name="pricem2" value="<?=$dgOrder_settings['pricem2']?>">
                <input type="hidden" id="FACTURE" name="name-facture" value="10">
                <input type="hidden" id="crop-img-src" name="crop-img-src">

                <label>Ваше имя: <input type="text" name="Name" ></label><br>
                <label>Ваш телефон: <input type="text" name="Phone" ></label><br>
                <label>Ваш email: <input type="text" name="Email" ></label><br>
                Комментарий к заказу:<br>
                <textarea cols="50" rows="5" name="Note" placeholder="Комментарий к заказу"></textarea><br>
                <input type="submit" name="dg-submit-order" value="Сделать заказ">
            </form>
        </div>


    </div>

    <?php
}

function dgCropImage()
{
    $aa = 10;
    /*    if (($x_o < 0) || ($y_o < 0) || ($w_o < 0) || ($h_o < 0)) {
            echo "Некорректные входные параметры";
            return false;
        }*/
    $image = get_attached_file($_POST['idimage']);
    // img[1] ширина img[2] высота
    list($w_i, $h_i, $type) = getimagesize($image); // Получаем размеры и тип изображения (число)
    $types = array("", "gif", "jpeg", "png"); // Массив с типами изображений
    $ext = $types[$type]; // Зная "числовой" тип изображения, узнаём название типа
    if ($ext) {
        $func = 'imagecreatefrom' . $ext; // Получаем название функции, соответствующую типу, для создания изображения
        $img_i = $func($image); // Создаём дескриптор для работы с исходным изображением
    } else {
        echo 'Некорректное изображение'; // Выводим ошибку, если формат изображения недопустимый
        return false;
    }
//    if ($x_o + $w_o > $w_i) $w_o = $w_i - $x_o; // Если ширина выходного изображения больше исходного (с учётом x_o), то уменьшаем её
//    if ($y_o + $h_o > $h_i) $h_o = $h_i - $y_o; // Если высота выходного изображения больше исходного (с учётом y_o), то уменьшаем её
    $img_o = imagecreatetruecolor($_POST['w'], $_POST['h']); // Создаём дескриптор для выходного изображения
    imagecopy($img_o, $img_i, 0, 0, $_POST['x'], $_POST['y'], $_POST['w'], $_POST['h']); // Переносим часть изображения из исходного в выходное
    $func = 'image' . $ext; // Получаем функция для сохранения результата
    $image_url = plugins_url('/crops/' . MTRAND . '.' . $ext, __FILE__);
    $file = plugin_dir_path(__FILE__) . 'crops/' . $_POST['MTRAND'] . '.jpg';
    $func($img_o, $file); // Сохраняем изображение в тот же файл, что и исходное, возвращая результат этой операции
    $ret = array();
    $ret['image_url'] = plugins_url('/crops/' . $_POST['MTRAND'] . '.jpg', __FILE__);
    echo json_encode($ret);
    die();
}
